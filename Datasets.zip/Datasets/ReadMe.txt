1. CoyoteMissingBothArms
This study aimed at comparing two techniques for extracting DNA from coyote blood samples.
One technique was the QIAGEN DNeasyr Blood and Tissue Kit, while the other was the chloroform isoamyl
alcohol method. The study includes 30 different coyotes and the outcome measure is the concentration of DNA. 
Due to time and cost constraints, the researcher selected 6 coyotes at random and tested their DNA using 
both techniques, 8 with the kit and 16 with chloroform.
For more details: Riordan (2012)

2. GeneMissingOneArm
Breast Cancer Study: Gene Expression Data. A breast cancer study has been performed by TCGA to improve the ability of diagnosing,
treating and preventing breast cancer through investigating the genetic basis of carcinoma. Their study consists of 1093
breast cancer patients with Clinical and RNA sequencing records. This TP53 gene dataset contains a subset of the original dataset,
including patients with pathologic stage. This subset contains a total of nc = 16 complete pairs and an unpaired
sample for the patients who developed only tumor tissues of size nu = 74.
For more details: Amro, Pauly & Ramosaj (2020)

3. KPSMissbotharms
Karnofsky Performance Status Scale (KPS) Dataset. This scale can be used for determining the prognosis
of individual patients or for comparing effectiveness of several therapies. The score ranges from 0 to
100. The lower the KPS score, the lower the probability of survival. In this dataset, KPS scores were used to assess the functional status of the patients on the day
before they died and their last day of life resulting in paired data.
For more details: Amro & Pauly (2017)

4. MigraineMissingBotharms
Clinical migraine study by Kostecki-Dillon et al. (1999). The study has been performed to
investigate four consecutive sessions of a nondrug headache program. Hereby, the headache severity level of 135 migraine
patientswasmeasured repeatedly on a daily basis by a scale ranging from 0 to 20. The lower the score, the better the clinical
record. In this dataset, we only use the clinical records of the patients in their first and third session.
For more details: Amro, Konietschke & Pauly (2019)

References: 
(1) Riordan, B. (2012). Northeastern ohio coyote hybridization with wolves. Honors
research project, University of Akron, Akron.
(2) Amro, L., Pauly, M., and Ramosaj, B. (2021). Asymptotic-based bootstrap
approach for matched pairs with missingness in a single-arm. Biometrical
Journal, 63(7), 1389-1405, DOI: 10.1002/bimj.202000051.
(3) Amro, L., and Pauly, M. (2017). Permuting incomplete paired data: a novel exact
and asymptotic correct randomization test. Journal of Statistical Computation
and Simulation, 87(6), 1148-1159, DOI: 10.1080/00949655.2016.1249871.
(4) Amro, L., Konietschke, F., and Pauly, M. (2019). Multiplication-Combination
Tests for Incomplete Paired Data. Statistics in Medicine, 38(17), 3243-3255,
DOI: 10.1002/sim.8178.